const getAsBool=(value)=>{
   return (value=="true"||value=="True")
}

module.exports={
    getAsBool
}