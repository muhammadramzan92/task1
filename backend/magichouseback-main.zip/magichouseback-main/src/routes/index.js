const authRoute = require("./authRoute");
const interiorRoutes = require("./interiorRoutes");
const subscriptionRoutes = require("./subscriptionRoutes");


module.exports={
    authRoute,
    interiorRoutes,
    subscriptionRoutes
}

